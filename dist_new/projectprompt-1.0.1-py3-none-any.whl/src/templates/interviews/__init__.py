#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Módulo de plantillas de entrevistas para ProjectPrompt.

Este paquete contiene las plantillas de preguntas utilizadas por el sistema
de entrevistas guiadas para obtener información detallada sobre funcionalidades.
"""
