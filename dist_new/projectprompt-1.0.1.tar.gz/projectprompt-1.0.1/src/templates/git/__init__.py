"""
Plantillas relacionadas con Git para ProjectPrompt.
"""
