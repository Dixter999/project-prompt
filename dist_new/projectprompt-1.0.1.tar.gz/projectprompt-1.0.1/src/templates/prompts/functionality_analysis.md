# Análisis de Funcionalidad: {functionality_name}

## Contexto del Proyecto
- **Nombre del Proyecto**: {project_name}
- **Lenguajes Principales**: {main_languages}
- **Archivos Analizados**: {file_count} en total
- **Fecha de Análisis**: {timestamp}

## Descripción de la Funcionalidad
{functionality_description}

## Archivos Principales
{main_files}

## Dependencias y Conexiones
{connections}

## Patrones Detectados
{patterns}

## Preguntas Guiadas para Aclaración
{guided_questions}

## Contexto Adicional
{additional_context}