"""ProjectPrompt - Asistente inteligente para análisis y documentación de proyectos usando IA."""

__version__ = "1.0.0"
