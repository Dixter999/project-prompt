"""
Core module for ProjectPrompt.
Contains essential functionality and base classes used throughout the project.
"""

__version__ = "0.1.0"